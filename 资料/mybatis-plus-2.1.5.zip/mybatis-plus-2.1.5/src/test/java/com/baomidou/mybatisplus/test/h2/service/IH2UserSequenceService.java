package com.baomidou.mybatisplus.test.h2.service;

import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.test.h2.entity.persistent.H2UserSequence;

/**
 * <p>
 * </p>
 *
 * @author yuxiaobin
 * @date 2017/6/26
 */
public interface IH2UserSequenceService extends IService<H2UserSequence> {

}
