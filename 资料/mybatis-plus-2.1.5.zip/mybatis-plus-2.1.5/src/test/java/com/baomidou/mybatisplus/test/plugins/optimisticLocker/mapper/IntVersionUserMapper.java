package com.baomidou.mybatisplus.test.plugins.optimisticLocker.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.plugins.optimisticLocker.entity.IntVersionUser;

public interface IntVersionUserMapper extends BaseMapper<IntVersionUser> {

}
