package com.baomidou.mybatisplus.test.h2.service;

import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.test.h2.entity.persistent.H2UserMetaObj;

/**
 * <p>
 * </p>
 *
 * @author yuxiaobin
 * @date 2017/6/27
 */
public interface IH2UserMetaobjService extends IService<H2UserMetaObj> {

}
