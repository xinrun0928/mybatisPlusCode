package com.baomidou.mybatisplus.test.oracle.service;

import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.test.oracle.entity.TestSequser;

/**
 * <p>
 * </p>
 *
 * @author yuxiaobin
 * @date 2017/6/14
 */
public interface OracleUserSeqService extends IService<TestSequser> {

}
