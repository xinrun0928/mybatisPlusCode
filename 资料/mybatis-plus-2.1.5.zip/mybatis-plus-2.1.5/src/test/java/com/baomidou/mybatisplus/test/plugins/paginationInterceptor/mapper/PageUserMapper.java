package com.baomidou.mybatisplus.test.plugins.paginationInterceptor.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.plugins.paginationInterceptor.entity.PageUser;

public interface PageUserMapper extends BaseMapper<PageUser> {

}
