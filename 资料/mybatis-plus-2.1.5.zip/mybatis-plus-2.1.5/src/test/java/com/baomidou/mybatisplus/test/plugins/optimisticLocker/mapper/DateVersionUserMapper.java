package com.baomidou.mybatisplus.test.plugins.optimisticLocker.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.plugins.optimisticLocker.entity.DateVersionUser;

public interface DateVersionUserMapper extends BaseMapper<DateVersionUser> {

}
