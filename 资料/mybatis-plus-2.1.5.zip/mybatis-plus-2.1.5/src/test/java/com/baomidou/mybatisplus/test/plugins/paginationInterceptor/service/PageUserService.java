package com.baomidou.mybatisplus.test.plugins.paginationInterceptor.service;

import com.baomidou.mybatisplus.service.IService;
import com.baomidou.mybatisplus.test.plugins.paginationInterceptor.entity.PageUser;

public interface PageUserService extends IService<PageUser> {

}
