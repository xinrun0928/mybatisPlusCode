insert into h2address(addr_id,addr_name,test_id) values(1,'Suzhou', 101);
insert into h2address(addr_id,addr_name,test_id) values(2,'Beijing', 101);
insert into h2address(addr_id,addr_name,test_id) values(3,'Shanghai', 101);
insert into h2address(addr_id,addr_name,test_id) values(4,'Guangzhou', 101);
insert into h2address(addr_id,addr_name,test_id) values(5,'Hangzhou', 101);