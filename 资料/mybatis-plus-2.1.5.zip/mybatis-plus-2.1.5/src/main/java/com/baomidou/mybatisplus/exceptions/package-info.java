/**
 * 异常类
 */
package com.baomidou.mybatisplus.exceptions;