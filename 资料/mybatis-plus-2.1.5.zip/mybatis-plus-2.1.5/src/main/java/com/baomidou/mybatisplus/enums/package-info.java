/**
 * 枚举类
 */
package com.baomidou.mybatisplus.enums;